<?php
require_once 'framework/modele.php';
class Commentaire extends Modele {
    // Renvoie la liste des commentaires associés à un article
   
    public function getCommentaires($idRecette) {
        // code à implémenter
        // retourne la liste des commentaires
        $req = "SELECT * FROM commentaire WHERE idRecette = ?";
        $param =array($idRecette);
        $execution = parent::executerRequete($req,$param);
        $donnees = $execution -> fetchAll();
        return $donnees;   
    }
    // Ajoute un commentaire dans la base
    public function ajouterCommentaire($auteur, $contenu, $idRecette, $note) {
        // code à implémenter
        // requête d'insert pour ajouter un commentaire'
        $dateCreation = date("Y-m-d h:i:s", time());
        $req = "INSERT INTO commentaire (idRecette, auteur, contenu, note, dateCreation) VALUES (?,?,?,?,?) ";
        $param = array($idRecette, $auteur, $contenu, $note, $dateCreation);
        parent::executerRequete($req, $param);
    
    }


}
