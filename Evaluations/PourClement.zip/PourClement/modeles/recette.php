<?php
require_once 'framework/modele.php';
class Recette extends Modele {
   
    public function getRecettes() {
        // code à implémenter
        // retourne la liste des recettes
        // utiliser pour cela executerRequete avec la requête SQL
        $sql = "SELECT * FROM recette";
        $execution = parent::executerRequete($sql);
        $donnees = $execution -> fetchAll();
        return $donnees;
    }

    // Renvoie les ingrédients correspondant a la recette
    public function getIngredients($idRecette) {
        // code à implémenter
        $sql = "SELECT * FROM ingredient  WHERE idRecette = ?";
        $param = array($idRecette);
        $execution = parent::executerRequete($sql,$param);
        $donnees = $execution -> fetchAll();
        return $donnees;
    }


    // Renvoie les informations sur une recette
    public function getRecette($idRecette) {
        // code à implémenter
        $sql = "SELECT * FROM recette WHERE id = ?";
        $param = array($idRecette);
        $execution = parent::executerRequete($sql,$param);
        $donnees = $execution -> fetchAll();
        return $donnees;
    }
}
?>