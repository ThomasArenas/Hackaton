<div id="global">
    <article>
        <header>
       <?php foreach( $donnees["recettes"]  as $donnee){ ?>
            <img class="imgRecette" src="img/<?php echo $donnee["photo"];?>" width="300px"
            height="242px" alt="<?php echo $donnee["titre"];?>" />
            <a href="index.php?controller=recette&action=recette&id=<?php echo $donnee["id"];?>">
                <h1 class="titreRecette">
                <?php echo $donnee["titre"];?>
                </h1>
            </a>
            <time>
            <?php echo $donnee["dateCreation"];?>
            </time>
        </header>
        <p>
        <?php echo $donnee["description"];?>
        </p>
    </article>
    <hr />
</div>
<?php } ?>