<?php  foreach( $donnees["recette"]  as $donnee){ ?>
<div id="global">
    <article>
        <header>
            <img class="imgRecette" src="img/<?php echo $donnee["photo"];?>" alt="<?php echo $donnee["titre"];?>" />
            <h1 class="titreRecette">
            <?php echo $donnee["titre"];?>
            </h1>
            <time>
            <?php echo $donnee["dateCreation"];?>
            </time>
        </header>
        <p>
        <?php echo $donnee["description"];?>
        </p>
        <?php }?>
    </article>
    <hr />
    
    <header>
        <h2 id="titreIngredient">
            Ingrédients
        </h2>
        <ul>
            <?php foreach( $donnees["ingredients"]  as $donnee){ ?>
            <li><?php echo $donnee["quantite"]; echo $donnee["unit"];?> <?php echo $donnee["nom"];?></li>
            <?php }?>
        </ul>
    </header>
    <h2 id="titreCommentaire">
        Commentaires
    </h2>
    <?php foreach( $donnees["commentaires"]  as $donnee){ ?>
    <div class="divCommentaire">
        <p><?php echo $donnee["auteur"];?> :  <?php echo $donnee["contenu"];?> </p>
        <p> Note : <?php echo $donnee["note"];?> </p>
        <p><?php echo $donnee["dateCreation"];?> </p>
        <hr>
    </div>
    <?php }?>
    <form method="post" action="index.php?controller=recette&action=commenter&id=<?php echo $donnees["id"]; ?>" >
        <input id="auteur" name="auteur" type="text" placeholder="Votre Nom"
        /><br />
        <textarea id="txtCommentaire" name="contenu" rows="4" placeholder="Votre
        commentaire" ></textarea><br/>
        <label for="note">Note</label><br />
        <select name="note" id="note">
            <option value="1">1</option>
            <option value="2">2</option>
            <option value="3">3</option>
            <option value="4">4</option>
            <option value="5">5</option>
        </select>
        <br />
        <input type="hidden" name="id" value="<?php echo $donnees["id"]; ?>" />
        <input type="submit" value="Commenter" />
    </form>
</div>