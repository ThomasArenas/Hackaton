<?php

/**
 * Requete short summary.
 *
 * Requete description.
 *
 * @version 1.0
 * @author Nicolas
 */
class Requete {

    // param�tres de la requ�te
    private $parametres;

    public function __construct($parametres) {
        $this->parametres = $parametres;
    }

    // Renvoie vrai si le param�tre existe dans la requ�te
    public function existeParametre($nom) {
        return (isset($this->parametres[$nom]) && $this->parametres[$nom] != "");
    }

    // Renvoie la valeur du param�tre demand�
    // L�ve une exception si le param�tre est introuvable
    public function getParametre($nom) {
        if ($this->existeParametre($nom)) {
            return $this->parametres[$nom];
        }
        else
            throw new Exception("Param�tre '$nom' absent de la requ�te");
    }
}
