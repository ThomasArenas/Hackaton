<?php
require_once 'modeles/recette.php';
require_once 'modeles/commentaire.php';
require_once 'framework/vue.php';
require_once 'framework/controller.php';
class ControllerRecette extends Controller {
    private $recette;
    private $commentaire;
    public function __construct() {
        $this->recette = new Recette();
        $this->commentaire = new Commentaire();
    }
    public function index(){
        
    }
    // Affiche les détails sur un article
    public function recette() {
        // code à implémenter
        //on recupère les paramètres
        $id = $this->requete->getParametre("id");
        //on appele la methode pour générer la vue
        $this->genererVue((array('recette'=> $this->recette->getRecette( $id ),'ingredients'=>$this->recette->getIngredients($id ),'id'=> $id,'commentaires'=>$this->commentaire->getCommentaires( $id ),'id'=> $id)));
    }
    // Ajoute un commentaire à une recette
    public function commenter() {
        // code à implémenter
        //on recupère les paramètres
        $idRecette = $this->requete->getParametre("id");
        $auteur = $this->requete->getParametre("auteur");
        $contenu = $this->requete->getParametre("contenu");
        $note = $this->requete->getParametre("note");
        //on appele la methode pour générer la vue
        $this->commentaire->ajouterCommentaire($auteur, $contenu, $idRecette, $note);
        //on change la valeur de $action pour rappeler le controlleurArticle
        $this->executerAction("recette");
       
        
    }
}
?>