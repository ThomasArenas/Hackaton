<?php
require_once 'modeles/recette.php';
require_once 'framework/vue.php';
require_once 'framework/controller.php';
class ControllerAccueil extends Controller {
    private $recette;
    public function __construct() {
        $this->recette = new Recette();
        
    }
    // Affiche la liste de tous les articles du blog
    public function index() {
        // code à implémenter
       //on appele la methode pour générer la vue
        $this->genererVue((array('recettes'=> $this->recette->getRecettes())));
    }
}
?>