<?php
require_once 'framework/modele.php';
class CommentaireDAO extends Modele {
    // Renvoie la liste des commentaires associés à une recette
   
    public function getCommentaires($idRecette) {
        // retourne la liste des commentaires
        $req = "SELECT * FROM commentaire WHERE idRecette = ?";
        $param =array($idRecette);
        $execution = parent::executerRequete($req,$param);
        $donnees = $execution -> fetchAll(PDO::FETCH_CLASS, 'Commentaire');
        return $donnees;   
    }
    // Ajoute un commentaire dans la base
    public function ajouterCommentaire($auteur, $contenu, $idRecette, $note) {
        // requête d'insert pour ajouter un commentaire'
        $dateCreation = date("Y-m-d h:i:s", time());
        $req = "INSERT INTO commentaire (idRecette, auteur, contenu, note, dateCreation) VALUES (?,?,?,?,?) ";
        $param = array($idRecette, $auteur, $contenu, $note, $dateCreation);
        parent::executerRequete($req, $param);
    
    }


}