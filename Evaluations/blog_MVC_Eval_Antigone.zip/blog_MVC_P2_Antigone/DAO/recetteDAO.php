<?php
require_once 'framework/modele.php';
class RecetteDAO extends Modele {
   
    function __construct() {
      
    }
    public function getRecettes() {
        // retourne la liste des recettes
        $sql = "SELECT * FROM recette";
        $execution = parent::executerRequete($sql);
        $donnees = $execution -> fetchAll(PDO::FETCH_CLASS, 'Recette');
        return $donnees;
    }

    // Renvoie les ingrédients correspondant a la recette
    public function getIngredients($idRecette) {
        // code à implémenter
        $sql = "SELECT * FROM ingredient  WHERE idRecette = ?";
        $param = array($idRecette);
        $execution = parent::executerRequete($sql,$param);
        $donnees = $execution -> fetchAll(PDO::FETCH_CLASS, 'Recette');
        return $donnees;
    }


    // Renvoie les informations sur une recette
    public function getRecette($idRecette) {
        $sql = "SELECT * FROM recette WHERE id = ?";
        $param = array($idRecette);
        $execution = parent::executerRequete($sql,$param);
        $execution->setFetchMode(PDO::FETCH_CLASS, 'Recette');
        $donnees = $execution->fetch();
        return $donnees;
    }
}
?>