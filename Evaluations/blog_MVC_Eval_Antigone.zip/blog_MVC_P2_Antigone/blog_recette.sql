-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1:3306
-- Généré le :  jeu. 03 déc. 2020 à 19:18
-- Version du serveur :  5.7.26
-- Version de PHP :  7.2.18

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `blog_recette`
--

-- --------------------------------------------------------

--
-- Structure de la table `categorie`
--

DROP TABLE IF EXISTS `categorie`;
CREATE TABLE IF NOT EXISTS `categorie` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nom` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `categorie`
--

INSERT INTO `categorie` (`id`, `nom`) VALUES
(1, 'Plat principale'),
(2, 'Entrée');

-- --------------------------------------------------------

--
-- Structure de la table `commentaire`
--

DROP TABLE IF EXISTS `commentaire`;
CREATE TABLE IF NOT EXISTS `commentaire` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idRecette` int(11) NOT NULL,
  `auteur` varchar(100) NOT NULL,
  `contenu` varchar(1000) NOT NULL,
  `note` int(11) NOT NULL,
  `dateCreation` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_Commentaire_Recette` (`idRecette`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `commentaire`
--

INSERT INTO `commentaire` (`id`, `idRecette`, `auteur`, `contenu`, `note`, `dateCreation`) VALUES
(13, 1, 'antigone', 'J\'adore la tartiflette', 5, '2020-12-03 06:13:36'),
(14, 1, 'Calypso', 'Moi j\'aime pas.', 1, '2020-12-03 06:13:49'),
(19, 2, 'Antigone', 'J\'aime pas la carottes ', 1, '2020-12-03 07:13:09'),
(20, 2, 'Calypso', 'Moi j\'adore !', 5, '2020-12-03 07:13:20');

-- --------------------------------------------------------

--
-- Structure de la table `ingredient`
--

DROP TABLE IF EXISTS `ingredient`;
CREATE TABLE IF NOT EXISTS `ingredient` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idRecette` int(11) NOT NULL,
  `nom` varchar(100) NOT NULL,
  `quantite` int(11) NOT NULL,
  `unit` char(2) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_Commentaire_Recette` (`idRecette`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `ingredient`
--

INSERT INTO `ingredient` (`id`, `idRecette`, `nom`, `quantite`, `unit`) VALUES
(1, 1, 'Pommes de  terre ', 750, 'g'),
(2, 1, 'Reblochon', 1, 'u'),
(3, 1, 'Lardons', 200, 'g'),
(4, 1, 'Crème fraîche épaisse', 3, 'cs'),
(5, 1, 'Oignons', 2, 'u'),
(6, 1, 'Beurre', 20, 'g'),
(7, 1, 'Sel', 1, 'cc'),
(8, 1, 'Poivre', 1, 'p'),
(9, 2, 'Carottes', 800, 'g'),
(10, 2, 'Oignon', 1, 'u'),
(11, 2, 'Bouillon de volaille', 1, 'l'),
(12, 2, 'Cumin', 1, 'cs'),
(13, 2, 'Crème fraîche épaisse', 2, 'cs'),
(14, 2, 'Huile d’olive', 2, 'cs'),
(15, 2, 'Sel', 1, 'cc'),
(16, 2, 'Poivre', 1, 'p');

-- --------------------------------------------------------

--
-- Structure de la table `membre`
--

DROP TABLE IF EXISTS `membre`;
CREATE TABLE IF NOT EXISTS `membre` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nom` varchar(100) NOT NULL,
  `pseudo` varchar(100) NOT NULL,
  `mdp` varchar(20) NOT NULL,
  `email` varchar(200) NOT NULL,
  `dateInscription` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `membre`
--

INSERT INTO `membre` (`id`, `nom`, `pseudo`, `mdp`, `email`, `dateInscription`) VALUES
(1, 'Nicolas C.', 'nicolas01', '12345', 'nicolas.chevalier@epsi.fr', '2019-06-24 09:10:00');

-- --------------------------------------------------------

--
-- Structure de la table `recette`
--

DROP TABLE IF EXISTS `recette`;
CREATE TABLE IF NOT EXISTS `recette` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idMembre` int(11) NOT NULL,
  `idCategorie` int(11) DEFAULT NULL,
  `titre` varchar(100) NOT NULL,
  `description` varchar(2000) NOT NULL,
  `author` varchar(100) NOT NULL,
  `photo` varchar(250) NOT NULL,
  `dateCreation` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_recette_idMember_idx` (`idMembre`),
  KEY `fk_recette_idCategorie_idx` (`idCategorie`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `recette`
--

INSERT INTO `recette` (`id`, `idMembre`, `idCategorie`, `titre`, `description`, `author`, `photo`, `dateCreation`) VALUES
(1, 1, 1, 'Tartiflette', 'La tartiflette savoyarde est un gratin de pommes de terre avec du Reblochon fondu dessus', 'Nicolas', 'tartiflette.jpg', '2019-01-07 00:00:00'),
(2, 1, 2, 'Velouté de carottes au cumin', 'Un velouté de carotte au cumin', 'Nicolas', 'veloute-de-carotte-au-cumin.jpg', '2019-01-08 00:00:00');

--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `commentaire`
--
ALTER TABLE `commentaire`
  ADD CONSTRAINT `FK_Commentaire_Recette` FOREIGN KEY (`idRecette`) REFERENCES `recette` (`id`);

--
-- Contraintes pour la table `ingredient`
--
ALTER TABLE `ingredient`
  ADD CONSTRAINT `FK_Ingredient_Recette` FOREIGN KEY (`idRecette`) REFERENCES `recette` (`id`);

--
-- Contraintes pour la table `recette`
--
ALTER TABLE `recette`
  ADD CONSTRAINT `fk_recette_idCategorie` FOREIGN KEY (`idCategorie`) REFERENCES `categorie` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_recette_idMember` FOREIGN KEY (`idMembre`) REFERENCES `membre` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
