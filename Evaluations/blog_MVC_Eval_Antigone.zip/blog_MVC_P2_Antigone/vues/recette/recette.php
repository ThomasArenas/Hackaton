<div id="global">
    <article>
        <header>
            <img class="imgRecette" src="img/<?php echo $donnees['recette']->getPhoto();?>" alt="<?php echo $donnees['recette']->getTitre();?>" />
            <h1 class="titreRecette">
            <?php echo $donnees['recette']->getTitre();?>
            </h1>
            <time class="date">
            <?php echo $donnees['recette']->getDateCreation();?>
            </time>
        </header>
        <p>
        <?php echo $donnees['recette']->getDescription();?>
        </p>
    </article>
    <hr />
    
    <header>
        <h2 id="titreIngredient">
            Ingrédients
        </h2>
        <ul>
            <?php foreach( $donnees["ingredients"]  as $donnee){ ?>
            <li><?php echo $donnee->getQuantite(); echo $donnee->getUnit();?> <?php echo $donnee->getNom();?></li>
            <?php }?>
        </ul>
    </header>
    <hr />
    <h2 id="titreCommentaire">
        Commentaires
    </h2>
    <?php foreach( $donnees["commentaires"]  as $donnee){ ?>
    <div class="divCommentaire">
        <p><span class="auteur"><?php echo $donnee->getAuteur();?> </span>:  <?php echo $donnee->getContenu();?> </p>
        <p class="note"> Note : <?php echo $donnee->getNote();?> </p>
        <p class="date"><?php echo $donnee->getDateCreation();?> </p>
        <hr>
    </div>
    <?php }?>
    <form method="post" action="index.php?controller=recette&action=commenter&id=<?php echo $donnees["id"]; ?>" >
        <input id="auteur" name="auteur" type="text" placeholder="Votre Nom"
        /><br />
        <textarea id="txtCommentaire" name="contenu" rows="4" placeholder="Votre
        commentaire" ></textarea><br/>
        <label for="note">Note</label><br />
        <select name="note" id="note">
            <option value="1">1</option>
            <option value="2">2</option>
            <option value="3">3</option>
            <option value="4">4</option>
            <option value="5">5</option>
        </select>
        <br />
        <input type="hidden" name="id" value="<?php echo $donnees["id"]; ?>" />
        <input type="submit" value="Commenter" />
    </form>
</div>