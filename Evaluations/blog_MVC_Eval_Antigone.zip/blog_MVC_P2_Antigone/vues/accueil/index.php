<?php foreach( $donnees["recettes"]  as $donnee){ ?>
<div id="global">
    <article>
        <header>
      
            <img class="imgRecette" src="img/<?php echo $donnee->getPhoto();?>" width="300px"
            height="242px" alt="<?php echo $donnee->getTitre();?>" />
            <a href="index.php?controller=recette&action=recette&id=<?php echo $donnee->getId();?>">
                <h1 class="titreRecette">
                <?php echo $donnee->getTitre();?>
                </h1>
            </a>
            <time>
            <?php echo $donnee->getDateCreation();?>
            </time>
        </header>
        <p>
        <?php echo $donnee->getDescription();?>
        </p>
    </article>
    <hr />
</div>
<?php } ?>