<?php
require_once 'DAO/commentaireDAO.php';
require_once 'DAO/recetteDAO.php';
require_once 'modeles/recette.php';
require_once 'modeles/commentaire.php';
require_once 'framework/vue.php';
require_once 'framework/controller.php';
class ControllerRecette extends Controller {
    private $recetteDAO;
    private $commentaireDAO;
    public function __construct() {
        $this->recetteDAO = new RecetteDAO();
        $this->commentaireDAO = new CommentaireDAO();
    }
    public function index(){
        
    }
    // Affiche les détails sur une recette
    public function recette() {
        //on recupère les paramètres
        $id = $this->requete->getParametre("id");
        //on appele la methode pour générer la vue
        $this->genererVue((array('recette'=> $this->recetteDAO->getRecette( $id ),'ingredients'=>$this->recetteDAO->getIngredients($id ),'id'=> $id,'commentaires'=>$this->commentaireDAO->getCommentaires( $id ),'id'=> $id)));
    }
    // Ajoute un commentaire à une recette
    public function commenter() {
        //on recupère les paramètres
        $idRecette = $this->requete->getParametre("id");
        $auteur = $this->requete->getParametre("auteur");
        $contenu = $this->requete->getParametre("contenu");
        $note = $this->requete->getParametre("note");
        //on appele la methode pour générer la vue
        $this->commentaireDAO->ajouterCommentaire($auteur, $contenu, $idRecette, $note);
        //on change la valeur de $action pour rappeler le controlleurRecette
        $this->executerAction("recette");
       
        
    }
}
?>