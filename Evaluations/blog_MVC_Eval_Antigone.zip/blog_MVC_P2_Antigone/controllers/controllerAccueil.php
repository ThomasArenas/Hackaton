<?php
require_once 'DAO/recetteDAO.php';
require_once 'modeles/recette.php';
require_once 'framework/vue.php';
require_once 'framework/controller.php';
class ControllerAccueil extends Controller {
    private $recetteDAO;
    public function __construct() {
        $this->recetteDAO = new RecetteDAO();
        
    }
    // Affiche la liste de toutes les recettes du blog
    public function index() {
        // code à implémenter
       //on appele la methode pour générer la vue
        $this->genererVue((array('recettes'=> $this->recetteDAO->getRecettes())));
    }
}
?>