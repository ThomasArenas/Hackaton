<?php

/**
 * Controller short summary.
 *
 * Controller description.
 *
 * @version 1.0
 * @author Nicolas
 */
require_once 'requete.php';
require_once 'vue.php';

abstract class Controller {

    // Action � r�aliser
    private $action;

    // Requ�te entrante
    protected $requete;

    // D�finit la requ�te entrante
    public function setRequete(Requete $requete) {
        $this->requete = $requete;
    }

    // Ex�cute l'action � r�aliser
    public function executerAction($action) {
        if (method_exists($this, $action)) {
            $this->action = $action;
            $this->{$this->action}();
        }
        else {
            $classeController = get_class($this);
            throw new Exception("Action '$action' non d�finie dans la classe $classeController");
        }
    }

    // M�thode abstraite correspondant � l'action par d�faut
    // Oblige les classes d�riv�es � impl�menter cette action par d�faut
    public abstract function index();

    // G�n�re la vue associ�e au contr�leur courant
    protected function genererVue($donneesVue = array()) {
        // D�termination du nom du fichier vue � partir du nom du contr�leur actuel
        $classeController = get_class($this);
        $controller = str_replace("Controller", "", $classeController);
        // Instanciation et g�n�ration de la vue
        $vue = new Vue($this->action, $controller);
        $vue->generer($donneesVue);
    }
}