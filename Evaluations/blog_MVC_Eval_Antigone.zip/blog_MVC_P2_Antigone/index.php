<?php

@ini_set('display_errors', 'on');	

require 'framework/router.php';

$router = new Routeur();
$router->routerRequete();

?>